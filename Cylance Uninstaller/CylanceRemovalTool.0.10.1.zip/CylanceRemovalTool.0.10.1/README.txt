
************************************************************************************************************
*  Support Tool: CylanceRemovalTool.exe
*  Created: 06/13/2022 by SDS
*  Updated: 05/29/2024 by SDS
*  Tracked via: KB 66473
*  Description: Automate the Windows cleanup of CylancePROTECT, CylanceOPTICS, CylanceAVERT, Cylance Smart Antivirus
*
*  Instructions for running:
*    1. Ensure you are running the _X86 and _X64 variant on the correct system. Examples below are using the _x64 variant
*    2. When possible, administrators should assign a policy with "Prevent Service Shutdown" disabled,
*       Memory Protection disabled, as well as "Script Control" disabled.
*    2. When possible, run the EXE using the NT AUTHORITY\SYSTEM account. (example is using psexec -i -s)
*		Please ensure you download Psexec from Microsoft sysinternals
*		https://learn.microsoft.com/en-us/sysinternals/downloads/psexec
*    3. Run the EXE without "-r" as a test run
*    4. When ready to make changes, add the "-r" switch
*    5. In some cases, the EXE may require a reboot and or reboot and rerun of the EXE.
*    6. When running the script CMD is a better option vs PowerShell to aid with Script Control Policy
*
* Example for unattended runs as administrator
*  C:\<Path>\CylanceRemovalTool_x64.exe -f -u "mypassword" -l C:\<Log_Folder_Path>
*  C:\<Path>\CylanceRemovalTool_x64.exe -f -r -u "mypassword" -l C:\<Log_Folder_Path>
*
* Example for unattended runs as NT AUTHORITY\SYSTEM (Recommended)
*  C:\<Path>\psexec.exe -accepteula -i -s C:\<Path>\CylanceRemovalTool_x64.exe -u "mypassword" -l C:\<Log_Folder_Path>
*  C:\<Path>\psexec.exe -accepteula -i -s C:\<Path>\CylanceRemovalTool_x64.exe -r -u "mypassword" -l C:\<Log_Folder_Path>
*
************************************************************************************************************

EXE Version: 0.10.1.0
Script Version: 6.40
blocklist Version: <= 0.10.1.0 or 6.39

Note: All string options require the use of " instead of '
 -h, --help 				                    Shows this dialog
 -u, --uninstall-password=VALUE 	            The uninstall password used for this product
 -c, --partial-cleanup 			                When specified, ProgramData is backed up and restored. This should not be used unless advised.
 -r, --removal				                    When specified, the script is run *without* safemode
 -p, --pause				                    When specified, the script will pause before finishing.
 -S, --silent				                    Runs the program in Silent mode, minimizing window popups and similar.
 -l, --log=VALUE 			                    Saves the log to a file on disk. Specify a folder path. Defaults to TEMP.
 -t, --service-timeout <service-timeout>        Sets the timeouts for service start, restart, etc
 -f, --force-when-admin             	        The program should be run as System. This option allows the user to attempt to run without being System.
 -T, --trace                                    Sets logging level to its highest level.
 -q, --quiet                                    Sets logging level to its lowest level.
 -t, --service-timeout <service-timeout>        Sets the timeouts for service start, restart, etc

**Warning: Important Execution Information**
It is strongly advised not to run this tool with administrator privileges. Instead, utilize NT System Authority, such as PSexec, for optimal functionality. Running the tool as an administrator may result in incomplete operations and potential system disruptions.
Failure to use NT System Authority may require a machine reboot, and the tool may need to be executed a second time to ensure the proper removal of drivers and security measures in Windows.
Please exercise caution and adhere to the recommended execution procedures to avoid undesirable consequences.

Note: When using SCCM and Other systems management software's you must ensure the profile is configured to push the application as NT System. In SCCM, the setting is under SCCM -> Deployment Type -> Install behavior.

SCCM Error Code Assignment:
	0 = Success
	1 = Failure
	2 = Soft reboot
	3 = Soft reboot
	1, 4-17 = Failure

Exit Codes:
	Exit 0 - Script finished successfully.
	Exit 1 - Script Finished but services are still running. A restart and re-run of the script is required
	Exit 2 - Script Finished but some files are in use. A restart before reinstall is recommended
	Exit 3 - A restart is required prior to reinstallation of Protect.
	Exit 4 - Free Memory: xx MB is less than the required 400 MB.
	Exit 5 - It looks like you didn't call the executable with the appending .exe.
	Exit 6 - Caught exception with creating the output directory.
	Exit 7 - You are running a x86 version of Powershell on Windows x64. Registry cleanup may fail. Please switch to x64 version of powershell
	Exit 8 - DisableRegistryTools GPO is enabled. No changes can be made in the registry (force exits in all cases).
	Exit 9 - Invalid safemode flag (force exits in all cases)
	Exit 10 - An error occurred with backup/restore (force exits in all cases)
	Exit 11 - Exception caught while setting Protect SelfProtectionLevel (force exits in all cases)
	Exit 12 - Failed to create HKEY_CLASSES_ROOT keys (force exits in all cases)
	Exit 13 - Failed to re-enable Windows Defender (force exits in all cases)
	Exit 14 - Tool requires Powershell 3+ to be installed
	Exit 15 - The current version of the script has been blacklisted. Please grab an updated version.
	Exit 16 - The Script requires you to use NT Authority\System or add the -f switch
	Exit 17 - Another installation is already in progress. Complete that installation before proceeding with this uninstall


Examples:

	Running in Safemode:
		C:\<Path>\psexec.exe -accepteula -i -s C:\<Path>\CylanceRemovalTool_x64.exe -u "mypassword" -l C:\<Log_Folder_Path>

	Running in destruction mode:
		C:\<Path>\psexec.exe -accepteula -i -s C:\<Path>\CylanceRemovalTool_x64.exe -r -u "mypassword" -l C:\<Log_Folder_Path>

	With the provided commands, logs will be saved in two locations:
		1) the specified location for the -l switch
		2) in the C:\Windows\Temp directory under \Cylance_Removal_Tool_<Date>\

	These logs are crucial for support teams to effectively troubleshoot any issues. It is strongly recommended to execute the tool using PSexec or alternative methods, ensuring it runs under the NT System/Authority account.
	The tool can still function without PSexec; however, doing so may necessitate restarting the endpoint and running the tool multiple times. This is due to the nature of antivirus protections.

	Running in Safemode:
		C:\<Path>\CylanceRemovalTool_x64.exe -f -u "mypassword" -l C:\<Log_Folder_Path>

	Running in destruction mode:
		C:\<Path>\CylanceRemovalTool_x64.exe -f -r -u "mypassword" -l C:\<Log_Folder_Path>

	With the above commands, Logs will reside in two locations.
		1) In the location for the -l switch
		2) in the :\Users\<username>\AppData\Local\Temp directory under \Cylance_Removal_Tool_<Date>\

Release Notes 0.9.3.0:
    * Uninstall Tool now attempts to disable ELAM.
    * Removed the ability to check the locally applied policy as its keeping some files from being removed.
    * Updated Steps and text in the script to support the BlackBerry Software Download hosting.
    * Updated the Folder and file names to better reflect CylanceRemovalTool vs just Protect.
    * Fixed some errors when the CylanceRemovalTool was running as Admin and not as NT System.
    * Updated the online and blocklist checks to be use the new EXE version format.
    * Updated the script to only work on system with PowerShell >= 3 (SDS-1278).
    * Fixed a bug where the Uninstall Tool was not grabbing a copy of historical logs (SDS-1276).
    * Added logic to stop the CylanceRemovalTool if another Windows Install/Uninstall Error 1618 is running (SDS-1276). We now exit
      with exit code 17
    * If the CylanceRemovalTool was ran successfully and protect was reinstalled with no reboot in between, we could fail to boot with
      "Inaccessible_Boot_Device" (SDS-1280)

Release Notes 0.9.4.0:
    * SDS-1282 - Added more logic to ensure no driver is removed if the Registry key exists.
    * SDS-1282 - Ensure empty DRVSTORE folders are removed.
    * SDS-1279 - Add timestamps to Uninstall log.

Release Notes 0.10.1.0:
    * SDS-1285 - Remove AMPPL from the Script.
    * SDS-1292 - Add Hostname and FQDN print.
    * SDS-1295 - Added newer CylancePROTECT 3.2 MR2 and CylanceOPTICS 3.3 MR1 Support.
    * SDS-1290 - Updated -l switch to be a folder. All logs are not added/Combined within this Directory.
    * SDS-1290 - Increased the Shutdown Service timeout.
    * SDS-1284 - Fixed an issue where uninstall passwords with a space was not working on CylanceOPTICS uninstall attempts
    * SDS-1281 - Fix some small issues with Powershell 7
    * SDS-1290 - Added -t switch to specify the timeout in seconds. useful for older/slow systems
    * SDS-1297 - Change exit code in the exe from Exit 15 to Exit 16
    * SDS-1298 - Add specific error when x86 version of tool is executed on x64 OS
    * SDS-1296 - Uninstall Tool fails when you have a backslash on the end of the folder for the log -l switch
    * SDS-1305 - Cylance Uninstall tool fails in non-english language OS due to NT Authority\System localization
    * SDS-1306 - Fixed some cases where a reboot message should appear but does not
    * SDS-1308 - Fixed unexpected try catch
    * SDS-1311 - Enhancements SelfProtectionLevel checks
    * Small bug fixes
